import subprocess
import paho.mqtt.client as mqtt

BROKER_ADDRESS = "your.mqtt.broker"
BROKER_PORT = 8883  # Usually 8883 for MQTT over TLS

# Paths to your certificates and keys
CA_CERT = "/ktools/ca.crt"
CLIENT_CERT = "/ktools/client.crt"
CLIENT_KEY = "/ktools/client.key"

def run_command(command, message):
    msg = message.payload.decode()
    print(f"Running: {command} {msg} --noupdate")
    subprocess.run([command, msg, "--noupdate"])

def blacklist(client, userdata, message):
    run_command("blacklist", message)

def unblacklist(client, userdata, message):
    run_command("unblacklist", message)

def whitelist(client, userdata, message):
    run_command("whitelist", message)

def unwhitelist(client, userdata, message):
    run_command("unwhitelist", message)

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connected to MQTT broker with mTLS!")
        client.subscribe("blacklist")
        client.subscribe("unblacklist")
        client.subscribe("whitelist")
        client.subscribe("unwhitelist")
    else:
        print(f"Failed to connect, return code {rc}")

def on_message(client, userdata, message):
    topic = message.topic
    print(f"Received message on topic '{topic}': {message.payload.decode()}")
    if topic == "blacklist":
        blacklist(client, userdata, message)
    elif topic == "unblacklist":
        unblacklist(client, userdata, message)
    elif topic == "whitelist":
        whitelist(client, userdata, message)
    elif topic == "unwhitelist":
        unwhitelist(client, userdata, message)
    else:
        print(f"Unknown topic: {topic}")

def main():
    client = mqtt.Client()

    client.tls_set(ca_certs=CA_CERT,
                   certfile=CLIENT_CERT,
                   keyfile=CLIENT_KEY)

    client.tls_insecure_set(False)

    client.on_connect = on_connect
    client.on_message = on_message

    client.connect(BROKER_ADDRESS, BROKER_PORT, 60)
    client.loop_forever()

if __name__ == "__main__":
    main()
